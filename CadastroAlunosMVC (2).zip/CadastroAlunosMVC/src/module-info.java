/**
 * 
 */
/**
 * 
 */
module CadastroAlunosMVC {
	requires java.desktop;
	requires java.sql;
}