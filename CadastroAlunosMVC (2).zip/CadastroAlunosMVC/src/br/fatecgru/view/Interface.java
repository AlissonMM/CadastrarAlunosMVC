package br.fatecgru.view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.text.MaskFormatter;

import br.fatecgru.dao.AlunoDAO;
import br.fatecgru.dao.MatriculaDAO;
import br.fategru.model.Aluno;
import br.fategru.model.Matricula;

public class Interface extends JFrame {

	private static final long serialVersionUID = 1L;
	private JTextField txtRGM;
	private JTextField txtNome;
	private JTextField txtDataNascimento;
	private JTextField txtCPF;
	private JTextField txtEmail;
	private JTextField txtEndereco;
	private JTextField txtMunicipio;
	private JTextField txtCelular;
	private JTextField txtNotasNomeAluno;
	private JTextField txtNomeCursoAluno;
	private JTextField txtNotasRGM;
	private JTextField txtFaltas;
	private JTextField txtBoletimRGM;
	private JTextField txtBoletimAluno;
	private JTextField txtBoletimCurso;
	private JTextField txtBoletimFaltas;
	private JTextField txtBoletimDisciplina;
	private JTextField txtBoletimMedia;
	private JTextField txtMedia;
	private JTextField txtUF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface frame = new Interface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Interface() throws Exception {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 380);
		
		// Configurando fundo escuro
        getContentPane().setBackground(Color.BLACK);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.GRAY); // Altera a cor de fundo do JMenuBar
        menuBar.setForeground(Color.WHITE); // Altera a cor do texto do JMenuBar
        setJMenuBar(menuBar);
		
		JMenu mnAluno = new JMenu("Aluno");
		mnAluno.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.add(mnAluno);
		
		JMenuItem mntmSalvar = new JMenuItem("Salvar");
		mntmSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {			
				 try {
			            // Capturando os dados dos campos
			            String rgm = txtRGM.getText();
			            String nome = txtNome.getText();
			            String dataNascimento = txtDataNascimento.getText();
			            String cpf = txtCPF.getText();
			            String email = txtEmail.getText();
			            String endereco = txtEndereco.getText();
			            String municipio = txtMunicipio.getText();
			            String UF = txtUF.getText();
			            String celular = txtCelular.getText();

			            // Criando a instância do Aluno
			            Aluno aluno = new Aluno(rgm, nome, dataNascimento, cpf, email, endereco, municipio, UF, celular);

			            // Chamando o método do AlunoDAO para salvar
			            AlunoDAO alunoDAO = new AlunoDAO();
			            if(rgm == null) {
			            	JOptionPane.showMessageDialog(null, "RGM não pode ser vazio!");
			            }else {
			            	 alunoDAO.salvar(aluno);
			            	
			            }

			            // Mensagem de sucesso
			            JOptionPane.showMessageDialog(null, "Aluno salvo com sucesso!");

			        } catch (Exception ex) {
			            // Tratamento de erro
			            JOptionPane.showMessageDialog(null, "Erro ao salvar aluno: " + ex.getMessage());
			        }
			    }
		});
		
		mntmSalvar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
        mnAluno.add(mntmSalvar);
		
		mntmSalvar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
		mnAluno.add(mntmSalvar);
		
		JMenuItem mntmAlterar = new JMenuItem("Alterar");
		mntmAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// criei o objeto aluno
				Aluno aluno = new Aluno();
				aluno.setRGM(txtRGM.getText());
				aluno.setNome(txtNome.getText());
				aluno.setDataNascimento(txtDataNascimento.getText());
				aluno.setCpf(txtCPF.getText());
				aluno.setEmail(txtEmail.getText());
				aluno.setEndereco(txtEndereco.getText());
				aluno.setMunicipio(txtMunicipio.getText());
				aluno.setUF(txtUF.getText());
				aluno.setCelular(txtCelular.getText());
				
				try {
					// abri o BD
					AlunoDAO dao = new AlunoDAO();
					dao.atualizar(aluno);
					JOptionPane.showMessageDialog(null, "Alterado com Sucesso");
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null,e1.getMessage());

				}
				
			}
		});
		mnAluno.add(mntmAlterar);
		
		JMenuItem mntmConsultar = new JMenuItem("Consultar");
		mntmConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String RGM = txtRGM.getText();
				try {
					AlunoDAO dao = new AlunoDAO();
					Aluno aluno = dao.procurarAluno(RGM);
					txtNome.setText(aluno.getNome());
					txtDataNascimento.setText(aluno.getDataNascimento());
					txtCPF.setText(aluno.getCpf());
					txtEmail.setText(aluno.getEmail());
					txtEndereco.setText(aluno.getEndereco());
					txtMunicipio.setText(aluno.getMunicipio());
					txtUF.setText(aluno.getUF());
					txtCelular.setText(aluno.getCelular());
							
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null,e1.getMessage());

				}
			}
		});
		mnAluno.add(mntmConsultar);
		
		JMenuItem mntmExcluir = new JMenuItem("Excluir");
		mntmExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String RGM = txtRGM.getText();
				try {
					AlunoDAO dao = new AlunoDAO();
					dao.excluir(RGM);
					txtNome.setText(null);
					txtDataNascimento.setText(null);
					txtCPF.setText(null);
					txtEmail.setText(null);
					txtEndereco.setText(null);
					txtMunicipio.setText(null);
					txtUF.setText(null);
					txtCelular.setText(null);
					JOptionPane.showMessageDialog(null, "Usuário Excluído com Sucesso!!");
					
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null,e1.getMessage());

				}
			}
		});
		mnAluno.add(mntmExcluir);
		
		JSeparator separator = new JSeparator();
		mnAluno.add(separator);
		
		JMenuItem mntmSair = new JMenuItem("Sair");
		mntmSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.SHIFT_DOWN_MASK));
		mnAluno.add(mntmSair);
		
		JMenu mnNotasFaltas = new JMenu("Notas e Faltas");
		mnNotasFaltas.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		menuBar.add(mnNotasFaltas);
		
		JMenuItem mntmNotasSalvar = new JMenuItem("Salvar");
		mntmNotasSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            // Capturando os dados dos campos
		            String rgm = txtNotasRGM.getText();
		            String media = txtMedia.getText();
		            String faltas = txtFaltas.getText();
		            
		            
		            // Criando a instância do Aluno
		            Matricula matricula = new Matricula(rgm, media, faltas);
		            
		            // Chamando o método do AlunoDAO para salvar
		            MatriculaDAO matriculaDAO = new MatriculaDAO();
		            matriculaDAO.salvar(matricula);

		            // Mensagem de sucesso
		            JOptionPane.showMessageDialog(null, "Notas salvas com sucesso!");

		        } catch (Exception ex) {
		            // Tratamento de erro
		            JOptionPane.showMessageDialog(null, "Erro ao salvar notas: " + ex.getMessage());
		        }
				
			}
		});
		mnNotasFaltas.add(mntmNotasSalvar);
		
		JMenuItem mntmNotasAlterar = new JMenuItem("Alterar");
		mntmNotasAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            // Capturando os dados dos campos
		            String rgm = txtNotasRGM.getText();
		            String media = txtMedia.getText();
		            String faltas = txtFaltas.getText();
		               
		            // Chamando o método do AlunoDAO para salvar
		            MatriculaDAO matriculaDAO = new MatriculaDAO();
		            matriculaDAO.atualizar(rgm, media, faltas);

		            // Mensagem de sucesso
		            JOptionPane.showMessageDialog(null, "Notas atualizadas com sucesso!");

		        } catch (Exception ex) {
		            // Tratamento de erro
		            JOptionPane.showMessageDialog(null, "Erro ao atualizar notas: " + ex.getMessage());
		        }
				
			}
		});
		mntmNotasAlterar.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.SHIFT_DOWN_MASK));
		mnNotasFaltas.add(mntmNotasAlterar);
		
		JMenuItem mntmNotasExcluir = new JMenuItem("Excluir");
		mntmNotasExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            // Capturando os dados dos campos
		            String rgm = txtNotasRGM.getText();
		               
		            // Chamando o método do AlunoDAO para salvar
		            MatriculaDAO matriculaDAO = new MatriculaDAO();
		            matriculaDAO.excluir(rgm);

		            // Mensagem de sucesso
		            JOptionPane.showMessageDialog(null, "Notas excluidas com sucesso!");

		        } catch (Exception ex) {
		            // Tratamento de erro
		            JOptionPane.showMessageDialog(null, "Erro ao excluir notas: " + ex.getMessage());
		        }
				
				
				
			}
		});
		mnNotasFaltas.add(mntmNotasExcluir);
		
		JMenuItem mntmNotasConsultar = new JMenuItem("Consultar");
		mntmNotasConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            // Capturando os dados dos campos
		            String rgm = txtNotasRGM.getText();
		            String media = txtMedia.getText();
		            String faltas = txtFaltas.getText();
		            
		            // Chamando o método do AlunoDAO para salvar
		            MatriculaDAO matriculaDAO = new MatriculaDAO();
		            Matricula matricula = matriculaDAO.procurarMatricula(rgm);
		            AlunoDAO alunoDAO = new AlunoDAO();
		            Aluno aluno = alunoDAO.procurarAluno(rgm);
		            
		            txtNotasNomeAluno.setText(aluno.getNome());
		            txtNomeCursoAluno.setText("Análise e Desenvolvimento de Sistemas");
		            txtMedia.setText(matricula.getMedia());
		            txtFaltas.setText(matricula.getFaltas());


		        } catch (Exception ex) {
		            // Tratamento de erro
		            JOptionPane.showMessageDialog(null, "Erro ao salvar notas: " + ex.getMessage());
		        }
				
			}
		});
		mnNotasFaltas.add(mntmNotasConsultar);
		
		JMenu mnAjuda = new JMenu("Ajuda");
		menuBar.add(mnAjuda);
		
		JMenuItem mntmSobre = new JMenuItem("Sobre");
		mntmSobre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "SOCORRO!");
			}
		});
		mnAjuda.add(mntmSobre);
		getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 714, 293);
		getContentPane().add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Dados Pessoais", null, panel, null);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("RGM");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNewLabel.setBounds(10, 29, 56, 30);
		panel.add(lblNewLabel);
		
		JLabel lblFatec = new JLabel("FATEC Guarulhos");
		lblFatec.setHorizontalAlignment(SwingConstants.LEFT); // Alinhado à esquerda
		lblFatec.setFont(new Font("Tahoma", Font.BOLD, 25)); // Tamanho menor
		lblFatec.setForeground(Color.RED); // Cor vermelha
		lblFatec.setBounds(10, -5, 300, 40); // Ajuste a coordenada Y para um valor menor
		panel.add(lblFatec);
		
		JLabel lblFeitoPor = new JLabel("Feito por: Alisson Mayer Medeji");
		lblFeitoPor.setHorizontalAlignment(SwingConstants.RIGHT); // Alinhado à direita
		lblFeitoPor.setFont(new Font("Tahoma", Font.PLAIN, 12)); // Fonte Tahoma, tamanho menor
		lblFeitoPor.setForeground(Color.RED); // Cor petro
		lblFeitoPor.setBounds(430, 240, 250, 20); // Ajuste as coordenadas conforme necessário
		panel.add(lblFeitoPor);

		
		txtRGM = new JTextField();
		txtRGM.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtRGM.setBounds(100, 33, 200, 30); 
		panel.add(txtRGM);
		txtRGM.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setHorizontalAlignment(SwingConstants.LEFT);
		lblNome.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNome.setBounds(10, 70, 56, 30);
		panel.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtNome.setColumns(10);
		txtNome.setBounds(100, 74, 200, 30);
		panel.add(txtNome);
		
		JLabel lblCpf = new JLabel("Data de Nascimento");
		lblCpf.setHorizontalAlignment(SwingConstants.LEFT);
		lblCpf.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblCpf.setBounds(312, 70, 194, 30);
		panel.add(lblCpf);
		
		//txtDataNascimento = new JFormattedTextField(new MaskFormatter("##/##/####"));
		txtDataNascimento = new JTextField();
		txtDataNascimento = new JTextField();
		txtDataNascimento.setHorizontalAlignment(SwingConstants.CENTER);
		txtDataNascimento.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtDataNascimento.setColumns(10);
		txtDataNascimento.setBounds(501, 70, 149, 30);
		panel.add(txtDataNascimento);
		
		JLabel lblCpf_1 = new JLabel("CPF");
		lblCpf_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblCpf_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblCpf_1.setBounds(310, 29, 56, 30);
		panel.add(lblCpf_1);
		
		txtCPF = new JFormattedTextField();
		txtCPF.setHorizontalAlignment(SwingConstants.CENTER);
		txtCPF.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtCPF.setColumns(10);
		txtCPF.setBounds(376, 33, 274, 30);
		panel.add(txtCPF);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.LEFT);
		lblEmail.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblEmail.setBounds(10, 111, 56, 30);
		panel.add(lblEmail);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtEmail.setColumns(10);
		txtEmail.setBounds(100, 115, 550, 30);
		panel.add(txtEmail);
		
		JLabel lblEndereo = new JLabel("End.");
		lblEndereo.setHorizontalAlignment(SwingConstants.LEFT);
		lblEndereo.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblEndereo.setBounds(10, 152, 56, 30);
		panel.add(lblEndereo);
		
		txtEndereco = new JTextField();
		txtEndereco.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtEndereco.setColumns(10);
		txtEndereco.setBounds(100, 156, 550, 30);
		panel.add(txtEndereco);
		
		JLabel lblMunpio = new JLabel("Munípio");
		lblMunpio.setHorizontalAlignment(SwingConstants.LEFT);
		lblMunpio.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblMunpio.setBounds(10, 193, 92, 30);
		panel.add(lblMunpio);
		
		txtMunicipio = new JTextField();
		txtMunicipio.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtMunicipio.setColumns(10);
		txtMunicipio.setBounds(100, 197, 155, 30);
		panel.add(txtMunicipio);
		
		JLabel lblUf = new JLabel("UF");
		lblUf.setHorizontalAlignment(SwingConstants.LEFT);
		lblUf.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblUf.setBounds(265, 197, 32, 30);
		panel.add(lblUf);
		
		JLabel lblCelular = new JLabel("Celular");
		lblCelular.setHorizontalAlignment(SwingConstants.LEFT);
		lblCelular.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblCelular.setBounds(376, 197, 67, 30);
		panel.add(lblCelular);
		
		txtCelular = new JTextField();
		txtCelular.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtCelular.setColumns(10);
		txtCelular.setBounds(453, 197, 197, 30);
		panel.add(txtCelular);
		
		txtUF = new JFormattedTextField(new MaskFormatter("AA"));
		txtUF.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtUF.setColumns(10);
		txtUF.setBounds(299, 197, 67, 30);
		panel.add(txtUF);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Curso", null, panel_1, null);
		panel_1.setLayout(null);
		panel_1.setBackground(Color.LIGHT_GRAY);
		
		// Aba "Curso"
		JLabel lblCurso = new JLabel("Curso");
		lblCurso.setHorizontalAlignment(SwingConstants.LEFT);
		lblCurso.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblCurso.setBounds(10, 60, 56, 30);
		panel_1.add(lblCurso);

		JComboBox comboBoxCurso = new JComboBox();
		comboBoxCurso.setModel(new DefaultComboBoxModel(new String[] {"Análise e Desenvolvimento de Sistemas"}));
		comboBoxCurso.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBoxCurso.setBounds(95, 60, 300, 30); // Ajustando a largura
		panel_1.add(comboBoxCurso);

		JLabel lblCampus = new JLabel("Campus");
		lblCampus.setHorizontalAlignment(SwingConstants.LEFT);
		lblCampus.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblCampus.setBounds(410, 60, 75, 30);
		panel_1.add(lblCampus);

		JComboBox comboBoxCampus = new JComboBox();
		comboBoxCampus.setModel(new DefaultComboBoxModel(new String[] {"Guarulhos"}));
		comboBoxCampus.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBoxCampus.setBounds(485, 60, 160, 30); // Ajustando a largura
		panel_1.add(comboBoxCampus);

		JLabel lblPerodo = new JLabel("Período");
		lblPerodo.setHorizontalAlignment(SwingConstants.LEFT);
		lblPerodo.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblPerodo.setBounds(10, 100, 75, 30);
		panel_1.add(lblPerodo);
		
		panel_1.setBackground(Color.LIGHT_GRAY); // Cinza claro
		panel.setBackground(Color.LIGHT_GRAY);
		
		

		/*JRadioButton rdbtnMatutino = new JRadioButton("Matutino");
		rdbtnMatutino.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtnMatutino.setBounds(95, 100, 109, 23);
		panel_1.add(rdbtnMatutino);*/

		// Período
		JRadioButton rdbtnVespertino = new JRadioButton("Vespertino");
		rdbtnVespertino.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtnVespertino.setBounds(95, 100, 120, 23);
		rdbtnVespertino.setSelected(true); // Deixa o botão selecionado
		rdbtnVespertino.setEnabled(false); // Desabilita o botão para que não possa ser desmarcado
		panel_1.add(rdbtnVespertino);
		
		// Combobox para Disciplinas
		JComboBox comboBoxDisciplinas = new JComboBox();
		comboBoxDisciplinas.setModel(new DefaultComboBoxModel(new String[] {
		    "Programação Orientada a Objetos", 
		    "Programação para Dispositivos Móveis"
		}));
		comboBoxDisciplinas.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBoxDisciplinas.setBounds(95, 140, 300, 30); // Ajuste a posição conforme necessário
		panel_1.add(comboBoxDisciplinas);
		
		JLabel lblaaba = new JLabel("Disciplinas");
		lblaaba.setHorizontalAlignment(SwingConstants.LEFT);
		lblaaba.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblaaba.setBounds(5, 140, 100, 30);
		panel_1.add(lblaaba);

		/*JRadioButton rdbtnNoturno = new JRadioButton("Noturno");
		rdbtnNoturno.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdbtnNoturno.setBounds(328, 100, 109, 23);
		panel_1.add(rdbtnNoturno);*/
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Notas e Faltas", null, panel_2, null);
		panel_2.setLayout(null);
		panel_2.setBackground(Color.LIGHT_GRAY);
		
		txtNotasNomeAluno = new JTextField();
		txtNotasNomeAluno.setHorizontalAlignment(SwingConstants.CENTER);
		txtNotasNomeAluno.setText("-- Nome do Aluno --");
		txtNotasNomeAluno.setToolTipText("");
		txtNotasNomeAluno.setEditable(false);
		txtNotasNomeAluno.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtNotasNomeAluno.setColumns(10);
		txtNotasNomeAluno.setBounds(310, 62, 389, 30); // Y aumentado de 32 para 62
		panel_2.add(txtNotasNomeAluno);

		txtNomeCursoAluno = new JTextField();
		txtNomeCursoAluno.setText("-- Nome do Curso --");
		txtNomeCursoAluno.setHorizontalAlignment(SwingConstants.CENTER);
		txtNomeCursoAluno.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtNomeCursoAluno.setEditable(false);
		txtNomeCursoAluno.setColumns(10);
		txtNomeCursoAluno.setBounds(100, 103, 599, 30); // Y aumentado de 73 para 103
		panel_2.add(txtNomeCursoAluno);

		JLabel lblaaaaaa = new JLabel("Disciplinas");
		lblaaaaaa.setHorizontalAlignment(SwingConstants.LEFT);
		lblaaaaaa.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblaaaaaa.setBounds(10, 144, 89, 30); // Y aumentado de 114 para 144
		panel_2.add(lblaaaaaa);

		JLabel lblNewLabel_1 = new JLabel("RGM");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(10, 58, 56, 30); // Y aumentado de 28 para 58
		panel_2.add(lblNewLabel_1);

		txtNotasRGM = new JTextField();
		txtNotasRGM.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtNotasRGM.setColumns(10);
		txtNotasRGM.setBounds(100, 62, 200, 30); // Y aumentado de 32 para 62
		panel_2.add(txtNotasRGM);

		JComboBox comboBoxDisciplinas1 = new JComboBox();
		comboBoxDisciplinas1.setModel(new DefaultComboBoxModel(new String[] {
		    "Programação Orientada a Objetos", 
		    "Programação para Dispositivos Móveis"
		}));
		comboBoxDisciplinas1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBoxDisciplinas1.setBounds(100, 144, 599, 30); // Y aumentado de 114 para 144
		panel_2.add(comboBoxDisciplinas1);

		JComboBox comboBoxSemestre = new JComboBox();
		comboBoxSemestre.setModel(new DefaultComboBoxModel(new String[] {
		    "1º Semestre", 
		    "2º Semestre", 
		    "3º Semestre", 
		    "4º Semestre", 
		    "5º Semestre", 
		    "6º Semestre"
		}));
		comboBoxSemestre.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBoxSemestre.setBounds(100, 185, 100, 30); // Y aumentado de 155 para 185
		panel_2.add(comboBoxSemestre);

		JLabel lblSemestre = new JLabel("Semestre");
		lblSemestre.setHorizontalAlignment(SwingConstants.LEFT);
		lblSemestre.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblSemestre.setBounds(10, 185, 89, 30); // Y aumentado de 155 para 185
		panel_2.add(lblSemestre);

		JLabel lblNotas = new JLabel("Média Geral");
		lblNotas.setHorizontalAlignment(SwingConstants.LEFT);
		lblNotas.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNotas.setBounds(210, 185, 110, 30); // Y aumentado de 155 para 185
		panel_2.add(lblNotas);

		JLabel lblNewLabel_1_1 = new JLabel("Faltas");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(420, 183, 56, 30); // Y aumentado de 153 para 183
		panel_2.add(lblNewLabel_1_1);

		txtFaltas = new JTextField();
		txtFaltas.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtFaltas.setColumns(10);
		txtFaltas.setBounds(486, 185, 100, 30); // Y aumentado de 155 para 185
		panel_2.add(txtFaltas);

		txtMedia = new JTextField();
		txtMedia.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtMedia.setColumns(10);
		txtMedia.setBounds(310, 185, 100, 30); // Y aumentado de 155 para 185
		panel_2.add(txtMedia);

		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Boletim", null, panel_3, null);
		panel_3.setLayout(null);
		panel_3.setBackground(Color.LIGHT_GRAY);

		// Título do boletim
		JLabel lblBoletim = new JLabel("Boletim");
		lblBoletim.setHorizontalAlignment(SwingConstants.CENTER);
		lblBoletim.setFont(new Font("Segoe UI", Font.BOLD, 24));
		lblBoletim.setBounds(0, 10, 800, 40);
		panel_3.add(lblBoletim);
		
		
		JLabel lblCursosDisponiveis = new JLabel("Cursos Disponíveis");
		lblCursosDisponiveis.setHorizontalAlignment(SwingConstants.CENTER);
		lblCursosDisponiveis.setFont(new Font("Segoe UI", Font.BOLD, 24));
		lblCursosDisponiveis.setBounds(-40, 10, 800, 40); // Ajuste a coordenada X para 20
		panel_1.add(lblCursosDisponiveis);
		
		JLabel lblCursosDisponiveis1 = new JLabel("Média e Faltas");
		lblCursosDisponiveis1.setHorizontalAlignment(SwingConstants.CENTER);
		lblCursosDisponiveis1.setFont(new Font("Segoe UI", Font.BOLD, 24));
		lblCursosDisponiveis1.setBounds(-40, 10, 800, 40); // Ajuste a coordenada X para 20
		panel_2.add(lblCursosDisponiveis1);

		// RGM
		JLabel lblNewLabel_2 = new JLabel("RGM");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_2.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(10, 60, 56, 30); // Ajustado para baixo
		panel_3.add(lblNewLabel_2);

		txtBoletimRGM = new JTextField();
		txtBoletimRGM.setHorizontalAlignment(SwingConstants.CENTER);
		txtBoletimRGM.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtBoletimRGM.setColumns(10);
		txtBoletimRGM.setBounds(100, 60, 200, 30); // Ajustado para baixo
		panel_3.add(txtBoletimRGM);

		txtBoletimAluno = new JTextField();
		txtBoletimAluno.setText("-- Nome do Aluno --");
		txtBoletimAluno.setHorizontalAlignment(SwingConstants.CENTER);
		txtBoletimAluno.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtBoletimAluno.setEditable(false);
		txtBoletimAluno.setColumns(10);
		txtBoletimAluno.setBounds(100, 100, 599, 30); // Ajustado para baixo
		panel_3.add(txtBoletimAluno);

		txtBoletimCurso = new JTextField();
		txtBoletimCurso.setText("-- Nome do Curso --");
		txtBoletimCurso.setHorizontalAlignment(SwingConstants.CENTER);
		txtBoletimCurso.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtBoletimCurso.setEditable(false);
		txtBoletimCurso.setColumns(10);
		txtBoletimCurso.setBounds(100, 140, 599, 30); // Ajustado para baixo
		panel_3.add(txtBoletimCurso);

		JLabel lblCurso_1 = new JLabel("Curso");
		lblCurso_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblCurso_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblCurso_1.setBounds(10, 140, 56, 30); // Ajustado para baixo
		panel_3.add(lblCurso_1);

		JLabel lblDisciplinas_1 = new JLabel("Disciplinas");
		lblDisciplinas_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblDisciplinas_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblDisciplinas_1.setBounds(10, 180, 89, 30); // Ajustado para baixo
		panel_3.add(lblDisciplinas_1);

		txtBoletimDisciplina = new JTextField();
		txtBoletimDisciplina.setText("-- Disciplina --");
		txtBoletimDisciplina.setHorizontalAlignment(SwingConstants.CENTER);
		txtBoletimDisciplina.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtBoletimDisciplina.setEditable(false);
		txtBoletimDisciplina.setColumns(10);
		txtBoletimDisciplina.setBounds(100, 180, 599, 30); // Ajustado para baixo
		panel_3.add(txtBoletimDisciplina);

		JLabel lblNotas_1 = new JLabel("Média");
		lblNotas_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNotas_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNotas_1.setBounds(10, 220, 56, 30); // Ajustado para baixo
		panel_3.add(lblNotas_1);

		txtBoletimMedia = new JTextField();
		txtBoletimMedia.setText("-- Média --");
		txtBoletimMedia.setHorizontalAlignment(SwingConstants.CENTER);
		txtBoletimMedia.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtBoletimMedia.setEditable(false);
		txtBoletimMedia.setColumns(10);
		txtBoletimMedia.setBounds(100, 220, 100, 30); // Ajustado para baixo
		panel_3.add(txtBoletimMedia);

		JLabel lblNewLabel_1_1_1 = new JLabel("Faltas");
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		lblNewLabel_1_1_1.setBounds(210, 220, 56, 30); // Ajustado para baixo
		panel_3.add(lblNewLabel_1_1_1);

		txtBoletimFaltas = new JTextField();
		txtBoletimFaltas.setText("-- QntFaltas --");
		txtBoletimFaltas.setHorizontalAlignment(SwingConstants.CENTER);
		txtBoletimFaltas.setEditable(false);
		txtBoletimFaltas.setFont(new Font("Tahoma", Font.PLAIN, 16));
		txtBoletimFaltas.setColumns(10);
		txtBoletimFaltas.setBounds(270, 220, 100, 30); // Ajustado para baixo
		panel_3.add(txtBoletimFaltas);

		
		JButton btnBoletimConsultar = new JButton("Consultar");
		btnBoletimConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            // Capturando os dados dos campos
		            String rgm = txtBoletimRGM.getText();
		            
		            // Chamando o método do AlunoDAO para salvar
		            MatriculaDAO matriculaDAO = new MatriculaDAO();
		            Matricula matricula = matriculaDAO.procurarMatricula(rgm);
		            AlunoDAO alunoDAO = new AlunoDAO();
		            Aluno aluno = alunoDAO.procurarAluno(rgm);
		            
		            txtBoletimAluno.setText(aluno.getNome());
		            txtBoletimCurso.setText("Análise e Desenvolvimento de Sistemas");
		            txtBoletimDisciplina.setText("Programação orientada a objetos, Programação para dispositivos móveis");
		            txtBoletimMedia.setText(matricula.getMedia());
		            txtBoletimFaltas.setText(matricula.getFaltas());


		        } catch (Exception ex) {
		            // Tratamento de erro
		            JOptionPane.showMessageDialog(null, "Erro ao mostrar boletim " + ex.getMessage());
		        }
				
			}
		});
		btnBoletimConsultar.setFont(new Font("Tahoma", Font.PLAIN, 16)); 
		btnBoletimConsultar.setBounds(300, 60, 130, 30); // Ajustado para mover mais para baixo
		panel_3.add(btnBoletimConsultar);

	}
}
