package br.fatecgru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fatecgru.util.ConnectionFactory;
import br.fategru.model.Disciplina;

public class DisciplinaDAO {
	private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;

    public DisciplinaDAO() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
        } catch (Exception e) {
            throw new Exception("Erro: \n" + e.getMessage());
        }
    }
    
    // Método para salvar disciplina
    public void salvar(Disciplina disciplina) throws Exception {
        if (disciplina == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "INSERT INTO Disciplina (nome_disciplina, id_curso) VALUES (?, ?)";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, disciplina.getNomeDisciplina());
            ps.setInt(2, disciplina.getIdCurso());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao inserir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para atualizar disciplina
    public void atualizar(Disciplina disciplina) throws Exception {
        if (disciplina == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "UPDATE Disciplina SET nome_disciplina=?, id_curso=? WHERE id_disciplina=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, disciplina.getNomeDisciplina());
            ps.setInt(2, disciplina.getIdCurso());
            ps.setInt(3, disciplina.getIdDisciplina());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao alterar dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para excluir disciplina
    public void excluir(Disciplina disciplina) throws Exception {
        if (disciplina == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "DELETE FROM Disciplina WHERE id_disciplina=?";
            ps = conn.prepareStatement(SQL);
            ps.setInt(1, disciplina.getIdDisciplina());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao excluir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para listar disciplinas
    public List<Disciplina> listarDisciplinas() throws Exception {
        try {
            ps = conn.prepareStatement("SELECT * FROM Disciplina");
            rs = ps.executeQuery();
            List<Disciplina> list = new ArrayList<>();
            while (rs.next()) {
                int idDisciplina = rs.getInt("id_disciplina");
                String nomeDisciplina = rs.getString("nome_disciplina");
                int idCurso = rs.getInt("id_curso");
                list.add(new Disciplina(idDisciplina, nomeDisciplina, idCurso));
            }
            return list;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao listar disciplinas: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

    // Método para procurar disciplina
    public Disciplina procurarDisciplina(int idDisciplina) throws Exception {
        try {
            String SQL = "SELECT * FROM Disciplina WHERE id_disciplina=?";
            ps = conn.prepareStatement(SQL);
            ps.setInt(1, idDisciplina);
            rs = ps.executeQuery();
            if (rs.next()) {
                String nomeDisciplina = rs.getString("nome_disciplina");
                int idCurso = rs.getInt("id_curso");
                return new Disciplina(idDisciplina, nomeDisciplina, idCurso);
            }
            return null;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao procurar disciplina: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

}
