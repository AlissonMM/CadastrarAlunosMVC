package br.fatecgru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fatecgru.util.ConnectionFactory;
import br.fategru.model.Aluno;

public class AlunoDAO {
	private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;
    private Aluno aluno;
    
    public AlunoDAO() throws Exception {
        // Chama a classe ConnectionFactory e estabelece uma conexão
        try {
            this.conn = ConnectionFactory.getConnection();
        } catch (Exception e) {
            throw new Exception("Erro: \n" + e.getMessage());
        }
    }
    
    // Método de salvar
    public void salvar(Aluno aluno) throws Exception {
        if (aluno == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "INSERT INTO Aluno (RGM, nome, data_nascimento, cpf, email, endereco, municipio, UF, celular) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, aluno.getRGM()); // RGM
            ps.setString(2, aluno.getNome());
            ps.setString(3, aluno.getDataNascimento());
            ps.setString(4, aluno.getCpf());
            ps.setString(5, aluno.getEmail());
            ps.setString(6, aluno.getEndereco());
            ps.setString(7, aluno.getMunicipio());
            ps.setString(8, aluno.getUF());
            ps.setString(9, aluno.getCelular());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao inserir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método de atualizar
    public void atualizar(Aluno aluno) throws Exception {
        if (aluno == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "UPDATE Aluno SET nome=?, data_nascimento=?, cpf=?, email=?, endereco=?, municipio=?, UF=?, celular=? "
                    + "WHERE RGM=?";
            ps = conn.prepareStatement(SQL);
            
            ps.setString(1, aluno.getNome());
            ps.setString(2, aluno.getDataNascimento());
            ps.setString(3, aluno.getCpf());
            ps.setString(4, aluno.getEmail());
            ps.setString(5, aluno.getEndereco());
            ps.setString(6, aluno.getMunicipio());
            ps.setString(7, aluno.getUF());
            ps.setString(8, aluno.getCelular());
            ps.setString(9, aluno.getRGM());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao alterar dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método de excluir
    public void excluir(String RGM) throws Exception {
        if (RGM == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "DELETE FROM Aluno WHERE RGM=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, RGM);
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao excluir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para listar alunos
    public List<Aluno> listarAlunos() throws Exception {
        try {
            ps = conn.prepareStatement("SELECT * FROM Aluno");
            rs = ps.executeQuery();
            List<Aluno> list = new ArrayList<Aluno>();
            while (rs.next()) {
                String RGM = rs.getString("RGM");
                String nome = rs.getString("nome");
                String dataNascimento = rs.getString("data_nascimento");
                String cpf = rs.getString("cpf");
                String email = rs.getString("email");
                String endereco = rs.getString("endereco");
                String municipio = rs.getString("municipio");
                String UF = rs.getString("UF");
                String celular = rs.getString("celular");
                list.add(new Aluno(RGM, nome, dataNascimento, cpf, email, endereco, municipio, UF, celular));
            }
            return list;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao listar alunos: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

    // Método para procurar aluno
    public Aluno procurarAluno(String RGM) throws Exception {
        try {
            String SQL = "SELECT * FROM Aluno WHERE RGM=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, RGM);
            rs = ps.executeQuery();
            if (rs.next()) {
                String nome = rs.getString("nome");
                String dataNascimento = rs.getString("data_nascimento");
                String cpf = rs.getString("cpf");
                String email = rs.getString("email");
                String endereco = rs.getString("endereco");
                String municipio = rs.getString("municipio");
                String UF = rs.getString("UF");
                String celular = rs.getString("celular");
                aluno = new Aluno(RGM, nome, dataNascimento, cpf, email, endereco, municipio, UF, celular);
            }
            return aluno;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao procurar aluno: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

}
