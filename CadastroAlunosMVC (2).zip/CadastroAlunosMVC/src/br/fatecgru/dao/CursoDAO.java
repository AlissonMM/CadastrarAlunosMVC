package br.fatecgru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fatecgru.util.ConnectionFactory;
import br.fategru.model.Curso;

public class CursoDAO {
	private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;

    public CursoDAO() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
        } catch (Exception e) {
            throw new Exception("Erro: \n" + e.getMessage());
        }
    }
    
    // Método para salvar curso
    public void salvar(Curso curso) throws Exception {
        if (curso == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "INSERT INTO Curso (nome_curso, turno, campus) VALUES (?, ?, ?)";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, curso.getNomeCurso());
            ps.setString(2, curso.getTurno());
            ps.setString(3, curso.getCampus());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao inserir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para atualizar curso
    public void atualizar(Curso curso) throws Exception {
        if (curso == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "UPDATE Curso SET nome_curso=?, turno=?, campus=? WHERE id_curso=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, curso.getNomeCurso());
            ps.setString(2, curso.getTurno());
            ps.setString(3, curso.getCampus());
            ps.setInt(4, curso.getIdCurso());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao alterar dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para excluir curso
    public void excluir(Curso curso) throws Exception {
        if (curso == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "DELETE FROM Curso WHERE id_curso=?";
            ps = conn.prepareStatement(SQL);
            ps.setInt(1, curso.getIdCurso());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao excluir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para listar cursos
    public List<Curso> listarCursos() throws Exception {
        try {
            ps = conn.prepareStatement("SELECT * FROM Curso");
            rs = ps.executeQuery();
            List<Curso> list = new ArrayList<>();
            while (rs.next()) {
                int idCurso = rs.getInt("id_curso");
                String nomeCurso = rs.getString("nome_curso");
                String turno = rs.getString("turno");
                String campus = rs.getString("campus");
                list.add(new Curso(idCurso, nomeCurso, turno, campus));
            }
            return list;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao listar cursos: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

    // Método para procurar curso
    public Curso procurarCurso(int idCurso) throws Exception {
        try {
            String SQL = "SELECT * FROM Curso WHERE id_curso=?";
            ps = conn.prepareStatement(SQL);
            ps.setInt(1, idCurso);
            rs = ps.executeQuery();
            if (rs.next()) {
                String nomeCurso = rs.getString("nome_curso");
                String turno = rs.getString("turno");
                String campus = rs.getString("campus");
                return new Curso(idCurso, nomeCurso, turno, campus);
            }
            return null;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao procurar curso: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

}
