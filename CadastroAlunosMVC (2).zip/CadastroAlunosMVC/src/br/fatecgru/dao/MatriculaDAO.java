package br.fatecgru.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fatecgru.util.ConnectionFactory;
import br.fategru.model.Matricula;

public class MatriculaDAO {
	private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs;

    public MatriculaDAO() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
        } catch (Exception e) {
            throw new Exception("Erro: \n" + e.getMessage());
        }
    }
    
    // Método para salvar matrícula
    public void salvar(Matricula matricula) throws Exception {
        if (matricula == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "INSERT INTO Matricula (RGM, id_curso, media, faltas) VALUES (?, 1, ?, ?)";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, matricula.getRGM());
            ps.setString(2, matricula.getMedia());
            ps.setString(3, matricula.getFaltas());
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao inserir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para atualizar matrícula
    public void atualizar(String RGM, String media, String faltas) throws Exception {
        if (RGM == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "UPDATE Matricula SET media=?, faltas=? WHERE RGM=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, media);
            ps.setString(2, faltas);
            ps.setString(3, RGM);
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao alterar dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para excluir matrícula
    public void excluir(String RGM) throws Exception {
        if (RGM == null)
            throw new Exception("O valor passado não pode ser nulo");
        try {
            String SQL = "DELETE FROM Matricula WHERE RGM=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, RGM);
            ps.executeUpdate();
        } catch (SQLException sqle) {
            throw new Exception("Erro ao excluir dados: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps);
        }
    }
    
    // Método para listar matrículas
    /*public List<Matricula> listarMatriculas() throws Exception {
        try {
            ps = conn.prepareStatement("SELECT * FROM Matricula");
            rs = ps.executeQuery();
            List<Matricula> list = new ArrayList<>();
            while (rs.next()) {
                int idMatricula = rs.getInt("id_matricula");
                String RGM = rs.getString("RGM");
                int idCurso = rs.getInt("id_curso");
                list.add(new Matricula(idMatricula, RGM, idCurso));
            }
            return list;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao listar matrículas: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }*/

    // Método para procurar matrícula
    public Matricula procurarMatricula(String RGM) throws Exception {
        try {
            String SQL = "SELECT * FROM Matricula WHERE RGM=?";
            ps = conn.prepareStatement(SQL);
            ps.setString(1, RGM);
            rs = ps.executeQuery();
            if (rs.next()) {
                String RGMs = rs.getString("RGM");
                int idMatricula = rs.getInt("id_matricula");
                String media = rs.getString("media");
                String faltas = rs.getString("faltas");
                
                return new Matricula(idMatricula, RGM, media, faltas);
            }
            return null;
        } catch (SQLException sqle) {
            throw new Exception("Erro ao procurar matrícula: " + sqle.getMessage());
        } finally {
            ConnectionFactory.closeConnection(conn, ps, rs);
        }
    }

}
