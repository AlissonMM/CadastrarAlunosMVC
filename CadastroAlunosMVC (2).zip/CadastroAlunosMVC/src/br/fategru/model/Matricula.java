package br.fategru.model;

public class Matricula {
	private int idMatricula;       // Chave primária
    private String RGM;            // Chave estrangeira
    private int idCurso;           // Chave estrangeira
    private String  media;
    private String faltas;

    // Construtor com parâmetros
    public Matricula(String RGM, String media, String faltas) {
        this.RGM = RGM;
        this.idCurso = 1;
        this.media = media;
        this.faltas = faltas;
    }
    
    public Matricula(int idMatricula, String RGM, String media, String faltas ) {
    	this.idMatricula = idMatricula;
    	this.RGM = RGM;
        this.idCurso = 1;
        this.media = media;
        this.faltas = faltas;
    	
    }

    // Construtor padrão
    public Matricula() {}

    // Getters e Setters
    public int getIdMatricula() {
        return idMatricula;
    }

    public void setIdMatricula(int idMatricula) {
        this.idMatricula = idMatricula;
    }

    public String getRGM() {
        return RGM;
    }

    public void setRGM(String RGM) {
        this.RGM = RGM;
    }

    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    public String getMedia() {
        return media;
    }

    public void setMedia(String media) {
        this.media = media;
    }

    public String getFaltas() {
        return faltas;
    }

    public void setFaltas(String faltas) {
        this.faltas = faltas;
    }

}
