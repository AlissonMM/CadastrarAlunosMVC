package br.fategru.model;

public class Aluno {
    private String RGM;          // Chave primária
    private String nome; 
    private String dataNascimento;  
    private String cpf;          // CPF é único e obrigatório
    private String email;
    private String endereco;  
    private String municipio;
    private String UF;          // Unidade Federativa
    private String celular;

    // Construtor com parâmetros
    public Aluno(String RGM, String nome, String dataNascimento, String cpf, String email, 
                 String endereco, String municipio, String UF, String celular) {
        this.RGM = RGM;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.cpf = cpf;
        this.email = email;
        this.endereco = endereco;
        this.municipio = municipio;
        this.UF = UF;
        this.celular = celular;
    }

    // Construtor padrão
    public Aluno() {}

    // Getters e Setters
    public String getRGM() {
        return RGM;
    }

    public void setRGM(String RGM) {
        this.RGM = RGM;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }
}