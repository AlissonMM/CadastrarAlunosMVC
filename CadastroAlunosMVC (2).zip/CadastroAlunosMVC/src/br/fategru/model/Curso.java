package br.fategru.model;

public class Curso {
	private int idCurso;       // Chave primária
    private String nomeCurso; 
    private String turno;
    private String campus;

    // Construtor com parâmetros
    public Curso(int idCurso, String nomeCurso, String turno, String campus) {
        this.idCurso = idCurso;
        this.nomeCurso = nomeCurso;
        this.turno = turno;
        this.campus = campus;
    }

    // Construtor padrão
    public Curso() {}

    // Getters e Setters
    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }
	

}
