package br.fategru.model;

public class Disciplina {
	private int idDisciplina;       // Chave primária
    private String nomeDisciplina; 
    private int idCurso;            // Chave estrangeira

    // Construtor com parâmetros
    public Disciplina(int idDisciplina, String nomeDisciplina, int idCurso) {
        this.idDisciplina = idDisciplina;
        this.nomeDisciplina = nomeDisciplina;
        this.idCurso = idCurso;
    }

    // Construtor padrão
    public Disciplina() {}

    // Getters e Setters
    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    public String getNomeDisciplina() {
        return nomeDisciplina;
    }

    public void setNomeDisciplina(String nomeDisciplina) {
        this.nomeDisciplina = nomeDisciplina;
    }

    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

}
